#!/bin/sh

pkill -9 dunst
notify-send "Dunst Restarted"
