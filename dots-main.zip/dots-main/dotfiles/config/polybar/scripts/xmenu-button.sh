#!/usr/bin/sh

while true; do
  # echo  
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 
  # echo 

  sleep 30 &
  wait
done
